#!/bin/sh
./proot -r ./ -w / -b /dev -b /proc -b /sys -q ./qemu-i386
