#!/bin/sh
mkdir PROOTTMP
export PROOT_TMP_DIR=`pwd`/PROOTTMP
./proot -r ./ -w / -b /dev -b /proc -b /sys -q ./qemu-i386
